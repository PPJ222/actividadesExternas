package Datos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import VO.SolicitudVO;
import VO.DatosProfsoradoVO;

public class SolicitudDAO {

	private static String driver = "com.mysql.jdbc.Driver";

	public static Connection obtenerConexion() {
		Connection conexion = null;

		try {
			Class.forName(driver);
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/ActividadesExternas", "root",
					"admin1234");
		} catch (Exception e) {
			System.out.println("error al obtener la conexión");
		}

		return conexion;
	}

	public static int guardarsolicitud(SolicitudVO solicitud, DatosProfsoradoVO dp) {

		int estado = 0;
		int idGenerado; 

		try {
			Connection conexion = SolicitudDAO.obtenerConexion();
			PreparedStatement ps = conexion
					.prepareStatement("INSERT INTO Solicitud(cod,DNI,Fecha,DC,Diurno,Nocturno) VALUES (null,?,?,?,?,?)",  Statement.RETURN_GENERATED_KEYS);
			
			 ps.setString(2, dp.getDNI());
			 ps.setDate(3, (Date) solicitud.getFecha());
			 ps.setBoolean(4, solicitud.isDC());
			 ps.setBoolean(5, solicitud.isDiurno());
			 ps.setBoolean(6, solicitud.isNocturno());
			 
			estado = ps.executeUpdate();
			
			ResultSet generatedKeys = ps.getGeneratedKeys();
			if (generatedKeys.next()) {
			         idGenerado = generatedKeys.getInt(1);
			         System.out.println("prueba: "+idGenerado);
			}
			
			// recuperamos el id de la actividad
			
			//creamos los insert de los grupos
			//solicitud.getHorario().getGrupo1()!=""
			

			conexion.close();

		} catch (Exception e) {

		}

		return estado;

	}

	public static List<SolicitudVO> obtenerSolicitud() {

		List<SolicitudVO> listaSolicitud = new ArrayList<SolicitudVO>();

		try {
			Connection conexion = SolicitudDAO.obtenerConexion();
			PreparedStatement ps = conexion.prepareStatement("SELECT * FROM Solicitud");
			ResultSet resultado = ps.executeQuery();

			while (resultado.next()) {
				
				 SolicitudVO solicitud = new SolicitudVO(); solicitud.setCod(resultado.getInt(1));
				  solicitud.setDNI(resultado.getString(2));
				 solicitud.setFecha(resultado.getDate(3));
				solicitud.setDC(resultado.getBoolean(4));
				solicitud.setDiurno(resultado.getBoolean(5));
				solicitud.setNocturno(resultado.getBoolean(6));
				listaSolicitud.add(solicitud);
				 
			}

			conexion.close();

		} catch (Exception e) {

		}

		return listaSolicitud;

	}
	
	public static int guardarDP(DatosProfsoradoVO dp) {

		int estado = 0;

		try {
			Connection conexion = SolicitudDAO.obtenerConexion();
			PreparedStatement ps = conexion
					.prepareStatement("INSERT INTO DatosProfsorado(DNI,Nombre,NRP,Domicilio,Telf,Departamento,ActividadEscolares) VALUES (?,?,?,?,?,?,?)");
			ps.setString(1, dp.getDNI());
			ps.setString(2, dp.getNombre());
			ps.setInt(3, dp.getNRP());
			ps.setString(4, dp.getDomicilio());
			ps.setInt(5, dp.getTelf());
			ps.setString(6, dp.getDepartamento());
			ps.setString(7, dp.getActividadEscolares());
			 
			estado = ps.executeUpdate();
			
			
			// recuperamos el id de la actividad
			
			//creamos los insert de los grupos
			//solicitud.getHorario().getGrupo1()!=""
			

			conexion.close();

		} catch (Exception e) {

		}

		return estado;

	}
}
