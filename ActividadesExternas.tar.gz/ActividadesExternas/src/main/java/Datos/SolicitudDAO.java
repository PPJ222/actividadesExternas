package Datos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import VO.SolicitudVO;

public class SolicitudDAO {

	private static String driver = "com.mysql.jdbc.Driver";

	public static Connection obtenerConexion() {
		Connection conexion = null;

		try {
			Class.forName(driver);
			conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/ActividadesExternas", "root",
					"admin1234");
		} catch (Exception e) {
			System.out.println("error al obtener la conexión");
		}

		return conexion;
	}

	public static int guardarActividades(SolicitudVO actividades) {

		int estado = 0;

		try {
			Connection conexion = SolicitudDAO.obtenerConexion();
			PreparedStatement ps = conexion
					.prepareStatement("INSERT INTO ActividadesExternas(nombre,password,email,zona) VALUES (?,?,?,?)");
			/*
			 * ps.setString(1, actividades.getNombre()); ps.setString(2,
			 * actividades.getPassword()); ps.setString(3, actividades.getEmail());
			 * ps.setString(4, actividades.getZona());
			 */
			estado = ps.executeUpdate();

			conexion.close();

		} catch (Exception e) {

		}

		return estado;

	}

	public static List<SolicitudVO> obtenerActividades() {

		List<SolicitudVO> listaActividades = new ArrayList<SolicitudVO>();

		try {
			Connection conexion = SolicitudDAO.obtenerConexion();
			PreparedStatement ps = conexion.prepareStatement("SELECT * FROM actividades");
			ResultSet resultado = ps.executeQuery();

			while (resultado.next()) {
				/*
				 * EmpleadoVO empleado = new EmpleadoVO(); empleado.setId(resultado.getInt(1));
				 * empleado.setNombre(resultado.getString(2));
				 * empleado.setPassword(resultado.getString(3));
				 * empleado.setEmail(resultado.getString(4));
				 * empleado.setZona(resultado.getString(5)); listaEmpleados.add(empleado);
				 */
			}

			conexion.close();

		} catch (Exception e) {

		}

		return listaActividades;

	}
}
