package VO;

public class HorarioVO {
	
	private int cod;
	private String Hora;
	private String Curso;
	private SolicitudVO solicitud;
	
	
	private String grupo1;
	private String grupo2;
	private String grupo3;
	private String grupo4;
	private String grupo5;
	private String grupo6;
	
	
	
	
	public HorarioVO() {
		super();
	}

	public HorarioVO(int cod, String hora, String curso, SolicitudVO solicitud) {
		super();
		this.cod = cod;
		Hora = hora;
		Curso = curso;
		this.solicitud = solicitud;
	}
	
	
	

	public String getGrupo1() {
		return grupo1;
	}

	public void setGrupo1(String grupo1) {
		this.grupo1 = grupo1;
	}

	public String getGrupo2() {
		return grupo2;
	}

	public void setGrupo2(String grupo2) {
		this.grupo2 = grupo2;
	}

	public String getGrupo3() {
		return grupo3;
	}

	public void setGrupo3(String grupo3) {
		this.grupo3 = grupo3;
	}

	public String getGrupo4() {
		return grupo4;
	}

	public void setGrupo4(String grupo4) {
		this.grupo4 = grupo4;
	}

	public String getGrupo5() {
		return grupo5;
	}

	public void setGrupo5(String grupo5) {
		this.grupo5 = grupo5;
	}

	public String getGrupo6() {
		return grupo6;
	}

	public void setGrupo6(String grupo6) {
		this.grupo6 = grupo6;
	}

	public int getCod() {
		return cod;
	}

	public void setCod(int cod) {
		this.cod = cod;
	}

	public String getHora() {
		return Hora;
	}

	public void setHora(String hora) {
		Hora = hora;
	}

	public String getCurso() {
		return Curso;
	}

	public void setCurso(String curso) {
		Curso = curso;
	}

	public SolicitudVO getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SolicitudVO solicitud) {
		this.solicitud = solicitud;
	}
			
}
