package VO;

public class HorarioVO {
	
	private int cod;
	private String Hora;
	private String Curso;
	private SolicitudVO solicitud;
	
	public HorarioVO() {
		super();
	}

	public HorarioVO(int cod, String hora, String curso, SolicitudVO solicitud) {
		super();
		this.cod = cod;
		Hora = hora;
		Curso = curso;
		this.solicitud = solicitud;
	}

	public int getCod() {
		return cod;
	}

	public void setCod(int cod) {
		this.cod = cod;
	}

	public String getHora() {
		return Hora;
	}

	public void setHora(String hora) {
		Hora = hora;
	}

	public String getCurso() {
		return Curso;
	}

	public void setCurso(String curso) {
		Curso = curso;
	}

	public SolicitudVO getSolicitud() {
		return solicitud;
	}

	public void setSolicitud(SolicitudVO solicitud) {
		this.solicitud = solicitud;
	}
			
}
