package VO;

public class DatosProfsoradoVO {
	private String DNI;
	private String Nombre;
	private int NRP;
	private String Domicilio;
	private int Telf;
	private String Departamento;
	private String ActividadEscolares;
	
	public DatosProfsoradoVO() {
		super();
	}

	public DatosProfsoradoVO(String dNI, String nombre, int nRP, String domicilio, int telf, String departamento,
			String actividadEscolares) {
		super();
		DNI = dNI;
		Nombre = nombre;
		NRP = nRP;
		Domicilio = domicilio;
		Telf = telf;
		Departamento = departamento;
		ActividadEscolares = actividadEscolares;
	}

	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dNI) {
		DNI = dNI;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public int getNRP() {
		return NRP;
	}

	public void setNRP(int nRP) {
		NRP = nRP;
	}

	public String getDomicilio() {
		return Domicilio;
	}

	public void setDomicilio(String domicilio) {
		Domicilio = domicilio;
	}

	public int getTelf() {
		return Telf;
	}

	public void setTelf(int telf) {
		Telf = telf;
	}

	public String getDepartamento() {
		return Departamento;
	}

	public void setDepartamento(String departamento) {
		Departamento = departamento;
	}

	public String getActividadEscolares() {
		return ActividadEscolares;
	}

	public void setActividadEscolares(String actividadEscolares) {
		ActividadEscolares = actividadEscolares;
	}

	
}
