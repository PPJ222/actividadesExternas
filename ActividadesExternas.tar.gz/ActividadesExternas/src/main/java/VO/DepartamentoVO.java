package VO;

public class DepartamentoVO {
	private String Nombre;
	
	public DepartamentoVO() {
		super();
	}

	public DepartamentoVO(String nombre) {
		super();
		Nombre = nombre;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}	
	
}
