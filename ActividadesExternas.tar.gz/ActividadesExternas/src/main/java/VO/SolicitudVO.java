package VO;

import java.util.Date;

public class SolicitudVO {
	private int cod;
	private String DNI;
	private Date Fecha;
	private boolean DC;
	private boolean Diurno;
	private boolean Nocturno;
	
	public SolicitudVO() {
		super();
	}

	public SolicitudVO(int cod, String dNI, Date fecha, boolean dC, boolean diurno, boolean nocturno) {
		super();
		this.cod = cod;
		DNI = dNI;
		Fecha = fecha;
		DC = dC;
		Diurno = diurno;
		Nocturno = nocturno;
	}

	public int getCod() {
		return cod;
	}

	public void setCod(int cod) {
		this.cod = cod;
	}

	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dNI) {
		DNI = dNI;
	}

	public Date getFecha() {
		return Fecha;
	}

	public void setFecha(Date fecha) {
		Fecha = fecha;
	}

	public boolean isDC() {
		return DC;
	}

	public void setDC(boolean dC) {
		DC = dC;
	}

	public boolean isDiurno() {
		return Diurno;
	}

	public void setDiurno(boolean diurno) {
		Diurno = diurno;
	}

	public boolean isNocturno() {
		return Nocturno;
	}

	public void setNocturno(boolean nocturno) {
		Nocturno = nocturno;
	}
	
	
	
}
