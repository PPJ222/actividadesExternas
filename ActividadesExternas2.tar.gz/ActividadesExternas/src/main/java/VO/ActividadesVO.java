package VO;

public class ActividadesVO {

}
